<?php
/**
 * @version		$Id: footer.php 5287 2018-06-17 20:59:37Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2018 OSWorX
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */
// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' Alle Rechte vorbehalten.<br />Dt. Übersetzung von &copy; <a href="https://www.opencart.cn" target="_blank">GuangDa Network</a>';
$_['text_version']= 'Version %s';