<?php

// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009 - ' . date('Y') . ' جميع الحقوق محفوظة<br />ترجمة <a href="http://www.opencart.cn" target="_blank">GuangDa Network</a>';
$_['text_version'] 	= 'الاصدار رقم %s';