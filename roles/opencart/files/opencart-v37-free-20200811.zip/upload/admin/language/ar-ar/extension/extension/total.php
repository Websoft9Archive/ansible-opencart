<?php

// Heading
$_['heading_title']     = 'إجماليات الطلب';

// Text
$_['text_success']      = 'تم التعديل !';
$_['text_list']         = 'قائمة';

// Column
$_['column_name']       = 'إجماليات الطلب';
$_['column_status']     = 'الحالة';
$_['column_sort_order'] = 'ترتيب الفرز';
$_['column_action']     = 'تحرير';

// Error
$_['error_permission']  = 'تحذير : أنت لا تمتلك صلاحيات التعديل !';